package Ejer1;

public abstract class MiembroUPV extends Persona{

	private String carnet;
	
	public MiembroUPV(String nombre, int edad) {
		super(nombre, edad);
		
	}
	
	public String isCarnet() {
		return carnet;
	}


	public void setCarnet(String carnet) {
		this.carnet = carnet;
	}

	public abstract void menuIntranet(); 
		
		
		
	
	

	
}
