package Ejer1;

import java.util.Scanner;

public class main_Ej0_T8 {

	public static void main(String[] args) {
		
		
		double[] notaEst = {7, 8.5, 4, 8, 6, 7.5, 5};
		
		
		MiembroUPV e1 = new Estudiante("Juan", 20,"Renault Clio Rojo", 12345, "1�DAM", notaEst );
		
		
		
		MiembroUPV p1 = new Profesor("Fernando", 45, "Opel Corsa Blanco", "D104", "Lunes de 10:00 a 13:00",1500);
		
		System.out.println("");
		
		e1.menuIntranet();
		
		System.out.println("");
		
		p1.menuIntranet();
	}
	
	
}
