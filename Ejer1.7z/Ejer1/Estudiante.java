package Ejer1;

import java.util.Scanner;

public class Estudiante extends MiembroUPV {

	private int NumeroExpediente;
	private String CursoActual;
	private double[] notas;

	public Estudiante(String nombre, int edad, String coche, int NumeroExpediente, String CursoActual, double[] notas) {
		super(nombre, edad);

		this.NumeroExpediente = NumeroExpediente;
		this.CursoActual = CursoActual;
		this.notas = notas;

	}

	public int getNumeroExpediente() {
		return NumeroExpediente;
	}

	public void setNumeroExpediente(int numeroExpediente) {
		NumeroExpediente = numeroExpediente;
	}

	public String getCursoActual() {
		return CursoActual;
	}

	public void setCursoActual(String cursoActual) {
		CursoActual = cursoActual;
	}

	public double[] getNotas() {
		return notas;
	}

	public void setNotas(double[] notas) {
		this.notas = notas;
	}

	public double getNotaMedia() {
		int i = 0;
		double media = 0;
		for (i = 0; i < notas.length; i++) {
			media = media + notas[i];
		}
		media = media / i;

		return media;

	}

	@Override
	public void menuIntranet() {

		Scanner sc = new Scanner(System.in);

		int menu;
		do {

			System.out.println("Bienvenido al men� Intranet estudiante, seleccione la operaci�n que desee hacer: ");

			System.out.println("1- Ver Expediente estudiante");

			System.out.println("2- �A qu� actividades deportivas desea apuntarse?");

			System.out.println("3- SALIR");

			menu = sc.nextInt();
			switch (menu) {

			case (1):

				System.out.println("" + this.getNombre() + " " + this.getEdad() + " " + this.getNumeroExpediente() + " "
						+ this.getCursoActual());

				break;
			case (2):

				String actividad = sc.next();
				break;
			case (3):

				System.out.println("HASTA LUEGO!Gracias por utilizar la Intranet estudiante");
				break;

			}
		} while (menu != 3);

	}
}
