package Ejer1;

import java.util.Scanner;

public class Profesor extends MiembroUPV {

	private String despacho;
	private String horasTutoria;
	private double nomina;

	public Profesor(String nombre, int edad, String coche, String despacho, String horasTutoria, double nomina) {
		super(nombre, edad);

		this.despacho = despacho;
		this.horasTutoria = horasTutoria;
		this.nomina=nomina;

	}

	public String getDespacho() {
		return despacho;
	}

	public void setDespacho(String despacho) {
		this.despacho = despacho;
	}

	public double getNomina() {
		return nomina;
	}

	public void setNomina(double nomina) {
		this.nomina = nomina;
	}

	public String getHorasTutoria() {
		return horasTutoria;
	}

	public void setHorasTutoria(String horasTutoria) {
		this.horasTutoria = horasTutoria;
	}

	public String getConsultas() {

		String resultado=this.horasTutoria;
		
		
		return resultado;
	}
	
	@Override
	public void menuIntranet() {
		
		Scanner sc = new Scanner(System.in);
		
		int menu;
		do {

			
			System.out.println("Bienvenido al men� Intranet profesor, seleccione la operaci�n que desee hacer: ");
			
			System.out.println("1- Ver la informaci�n del profesor");
			
			System.out.println("2- Ver n�mina del profesor");
			
			System.out.println("3- �A qu� actividades deportivas desea apuntarse?");
			
			
			System.out.println("4- SALIR");
			
			 menu = sc.nextInt();
			switch(menu) {
				
			case (1):
				
				
				
				System.out.println(this.getNombre()+" "+this.getEdad()+" "+this.getDespacho()+" "+this.getConsultas());
				break;
			case (2):
				
				System.out.println(this.getNomina());
				break;
			case (3): 
				
				String actividad = sc.next();
				break;
			case (4):
				
				System.out.println("HASTA LUEGO!Gracias por utilizar la Intranet de profesor");
				break;
			}
		}
		while(menu!=4); 
			
		
			
		
	}
	
	
}
